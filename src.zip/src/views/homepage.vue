<template>
    <el-container style="position: fixed;width: 100%">
      <el-header class="header" style="height: 50px">
        <topbar :username="username"></topbar>
      </el-header>
      <el-container>
        <el-aside class="aside" width="200px" style="margin-top: 4px;height: 100vh">
          <sidebar></sidebar>
        </el-aside>
        <el-main class="main" style="padding: 0; margin-top: 4px; margin-left: 4px;height: 95vh">
          <router-view>
          </router-view>
        </el-main>
      </el-container>
    </el-container>
</template>

<script>
  import topbar from '../public/common/topbar'
  import sidebar from '../public/common/sidebar'
  export default {
    name: "homepage",
    data(){
      return{
        username:'',
      }
    },
    components: {
      sidebar,
      topbar,
    }
  }
</script>

<style scoped>
  .header {
    background-color: #181f29;
  }

  .aside{
  }
  .main{
    padding: 10px;
    /*overflow: scroll;*/
  }
  .main::-webkit-scrollbar{
    width: 0;
  }

  .aside::-webkit-scrollbar{
    width: 0;
  }
</style>