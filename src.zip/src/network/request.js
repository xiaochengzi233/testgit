import axios from 'axios'

// export function request(config, params) {
//   // 创建连接实例
//   const instance_get = axios.create({
//     baseURL: 'http://192.168.1.100:8000/',
//     timeout: 2000,
//     // method: 'get',
//     // params:''
//   })
//   return instance_get(config);

  // axios拦截器
  // instance.interceptors.request;
  // instance.interceptors.response;
// }
axios.defaults.withCredentials = true;

export function request(config){
  const instance_post = axios.create({
    baseURL: 'http://192.168.1.100:8000/',
  })
  return instance_post(config);
}
