import Vue from 'vue';
import login from './views/login';
import ElementUI from 'element-ui';
// import 'element-ui/lib/theme-chalk/index.css';

import './assets/css/theme/index.css'
import './assets/css/cssreset.css'
import router from './router/index';
import topbar from './public/common/topbar';
import homepage from './views/homepage'
import warning_handle from './public/content/warning/warning_handle'
import sidebar from './public/common/sidebar'
// import axios from 'axios'

window.echarts = require('echarts');
Vue.use(ElementUI);

Vue.config.productionTip = false;

new Vue({
  render: h => h(homepage),
  router
}).$mount('#app')
