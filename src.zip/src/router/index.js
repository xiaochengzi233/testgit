import VueRouter from 'vue-router'
import Vue from 'vue'

import login from '../views/login'
import homepage from '../views/homepage'
import device_managesys from '../public/content/device/device_managesys'
import device_detail from '../public/content/device/device_detail'
import device_status from '../public/content/device/device_status'
import history_detail from '../public/content/device/history_detail'
import user_list from '../public/content/user/user_list'
import user_info from '../public/content/user/user_info'
import user_info_edit from '../public/content/user/user_info_edit'
import user_auth from '../public/content/user/user_auth'
import warning_list from '../public/content/warning/warning_list'
import warning_detail from '../public/content/warning/warning_detail'
import warning_handle from '../public/content/warning/warning_handle'

// 通过Vue.use()使用插件
Vue.use(VueRouter);
// 创建VueRouter对象，配置组件路由
const routes = [
  {
    path: '',
    redirect: '/device_managesys'
  },
  {
    path: '/login',
    component: login,
  },
  {
    path: '/homepage',
    component: homepage,
  },
  {
    path:'/device_managesys',
    component: device_managesys
  },
  {
    path:'/device_status',
    component: device_status
  },
  {
    path:'/history_detail',
    component: history_detail
  },
  {
    path:'/user_auth',
    component: user_auth
  },
  {
    path:'/user_info',
    component: user_info
  },
  {
    path:'/user_info_edit',
    component: user_info_edit
  },
  {
    path:'/user_list',
    component: user_list
  },
  {
    path:'/warning_list',
    component: warning_list
  },
  {
    path:'/warning_detail',
    component: warning_detail
  },
  {
    path:'/warning_handle',
    component: warning_handle
  }
]
const router = new VueRouter({
  routes,
  mode: 'history',
  // linkActiveClass: 'active'
})

// 将router对象传入到Vue实例
export default router;