<template>
  <div>
    设备状态
  </div>
</template>

<script>
  export default {
    name: "device_status"
  }
</script>

<style scoped>

</style>