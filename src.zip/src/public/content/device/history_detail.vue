<template>
  <div>
    设备详情
    <tabbar :tabname="tabname"></tabbar>
  </div>
</template>

<script>
  import tabbar from '../../common/tabbar'
  export default {
    name: "history_detail",
    data:{
      tabname:{
        all: '全部',
        normal: '正常运行',
        planned_stop: '计划停机',
        warning: '异常警告',
        hang_up: '意外停机',
        sensor_offline: '传感器离线'
      }
    },
    components:{
      tabbar
    }
  }
</script>

<style scoped>

</style>