<template>
  <div>
    <h2 style="color: white">设备信息</h2>
  </div>
</template>

<script>
  export default {
    name: "device_detail"
  }
</script>

<style scoped>

</style>