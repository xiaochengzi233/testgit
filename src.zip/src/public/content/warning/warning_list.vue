<template>
  <div>
    <!--topcard-->
    <el-card shadow="hover">
      <el-col style="margin-left: 1%"><h4 style="text-align: left">报警信息处理</h4></el-col>
      <el-row style="margin-left: 1%">
        <el-col :span="9">
          <el-row>
            <el-col :span="6"><h4>已选设备：</h4></el-col>
            <el-col :span="18">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="3"><el-button type="primary" plain style="text-align: center">选择设备</el-button></el-col>
        <el-col :span="3"><el-button type="warning" plain style="text-align: center">显示全部设备</el-button></el-col>
        <!--period-->
        <el-col :span="3" style="text-align: center">
          <el-select v-model="value_period" placeholder="请选择时段">
            <el-option
              v-for="item in options_period"
              :key="item.value_period"
              :label="item.label"
              :value="item.value_period">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="3" >
          <el-input v-model="input" placeholder="请输入要查找的设备" style="margin-left: 22%"></el-input>
        </el-col>
        <el-col :span="3" style="text-align: center">
          <el-button type="primary" icon="el-icon-search" plain="">查找</el-button>
        </el-col>
      </el-row>
    </el-card>
    <!--warningtablecard-->
    <div class="el-card" style="margin-top: 0.5%" >
      <el-row ><el-col style="margin-left: 2%"><h4 style="text-align: left">报警列表</h4></el-col></el-row>
      <!--maintable-->
      <div style="margin-left: 2%;margin-right: 2%">
        <el-row style="text-align: center" class="divborder">
          <el-col :span="1"><h5>编号</h5></el-col>
          <el-col :span="7"><h5>故障设备</h5></el-col>
          <el-col :span="3"><h5>发现时间</h5></el-col>
          <el-col :span="3"><h5>报警类型</h5></el-col>
          <el-col :span="4"><h5>来源</h5></el-col>
          <el-col :span="3"><h5>处理时间</h5></el-col>
          <el-col :span="3"><h5>操作</h5></el-col>
        </el-row>
        <div style="height: 52vh ; overflow: auto">
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
          <el-row style="text-align: center ; padding-top: 1% ; padding-bottom: 1%" class="divborder3">
            <el-col :span="1"><h5 style="margin-top: 16px">1</h5></el-col>
            <el-col :span="7">
              <el-row>
                <el-col :span="8" style="margin-top: 5px ; text-align: center">IMG</el-col>
                <el-col :span="16">
                  <h4 style="margin: 2px ;text-align: left">高岩注水泵 NO.0800968</h4>
                  <h6 style="margin: 2px ; text-align: left">东营胜利油田三号钻井</h6>
                  <h4 style="margin: 2px ; text-align: left">健康指标：<span style="color: red">32</span></h4>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">19:14</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px ; color: red">D区故障</h4></el-col>
            <el-col :span="4" style="margin-top: 14px"><h4 style="margin: 2px">NO.2010222.3</h4></el-col>
            <el-col :span="3" style="margin-top: 8px">
              <el-col><h4 style="margin: 2px">2019.11.16</h4></el-col>
              <el-col><h4 style="margin: 2px">20:20</h4></el-col>
            </el-col>
            <el-col :span="3" style="margin-top: 14px"><h4 style="margin: 2px">已处理</h4></el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        options_location: [{
          value_location: '选项1',
          label: '胜利油田31区'
        }, {
          value_location: '选项2',
          label: 'XX油田'
        }, {
          value_location: '选项3',
          label: 'CC油田'
        }, {
          value_location: '选项4',
          label: 'VV油田'
        }],
        value_location: '',
        options_device: [{
          value_device: '选项1',
          label: 'NO367抽水泵'
        }, {
          value_device: '选项2',
          label: '2号电机'
        }, {
          value_device: '选项3',
          label: '3号电机'
        }, {
          value_device: '选项4',
          label: '4号电机'
        }],
        value_device: '',
        options_period: [{
          value_period: '选项1',
          label: '本日'
        }, {
          value_period: '选项2',
          label: '本周'
        }, {
          value_period: '选项3',
          label: '本月'
        }],
        value_period: '',
        multipleSelection: []
      }
    },
    name: "warning_list"
  }
</script>
<style scoped>

  .divborder{ border:2px solid #000}

  .divborder3{ border:2px solid #000 ;border-top :0px }

  .bg-black {
    background-color: #181f29;
  }

  .bg-dark {
    background-color: #000000;
  }


  body > .el-container {
    margin-bottom: 40px;
  }

  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }

  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>