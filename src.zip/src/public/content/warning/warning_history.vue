<template>
  
</template>

<script>
  export default {
    name: "warning_history"
  }
</script>

<style scoped>

</style>