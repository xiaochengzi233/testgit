<template>
  
</template>

<script>
  export default {
    name: "warning_detail"
  }
</script>

<style scoped>

</style>