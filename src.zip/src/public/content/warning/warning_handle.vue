<!--homepage页面内容-->
<template>
  <el-card>
    <div slot="header">
      <span>告警处理</span>
    </div>
    <div>
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item label="处理人">
          <el-input v-model="form.handle_person"></el-input>
        </el-form-item>
        <el-form-item label="处理方式">
          <el-input v-model="form.handle_method"></el-input>
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.handle_description" type="textarea" :autosize="{ minRows: 5, maxRows: 10}"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">立即创建</el-button>
          <el-button>取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>

<script>
  import {request} from "@/network/request";
  export default {
    name: "warning_handle",
    data() {
      return {
        form: {
          report_id: '001',
          handle_person: '',
          handle_method: '',
          handle_description: '',
        },
      }
    },
    methods: {
      onSubmit() {
        // let form_warning = new FormData();
        // form_warning.append('report_id',this.form.report_id);
        // form_warning.append('handle_person',this.form.handle_person);
        // form_warning.append('handle_method',this.form.handle_method);
        // form_warning.append('handle_description',this.form.handle_description);
        // console.log(form_warning);
        request({
          url: 'warning/handle/',
          method: 'post',
          data: this.form,
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }).then(res => {
          console.log(res);
          this.$router.push('/homepage');
        }).catch(err => {
          console.log(err);
        })
        alert('submit!');
      }
    }
  }
</script>

<style scoped>

</style>