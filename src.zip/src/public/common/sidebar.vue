<!--homepage左侧菜单栏-->
<template>
    <el-menu
      :router="true"
      default-active="device_managesys"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      style="border:transparent; height: 100%"
      :default-openeds='["2"]'
      :unique-opened="true">
      <el-menu-item index="device_managesys">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>首页</span>
        </template>
      </el-menu-item>

      <el-submenu index="2">
        <template slot="title">
          <i class="el-icon-folder-opened"></i>
          <span slot="title">设备管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="device_managesys">设备管理系统</el-menu-item>
          <el-menu-item index="device_detail">设备详情</el-menu-item>
          <el-menu-item index="device_status">监测设备状态</el-menu-item>
          <el-menu-item index="history_detail">历史数据详情</el-menu-item>
        </el-menu-item-group>
      </el-submenu>

      <el-submenu index="3">
        <template slot="title">
          <i class="el-icon-bell"></i>
          <span slot="title">报警管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="warning_list">告警列表</el-menu-item>
          <el-menu-item index="warning_detail">告警详情</el-menu-item>
          <el-menu-item index="warning_handle">告警处理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>

      <el-submenu index="4">
        <template slot="title">
          <i class="el-icon-user"></i>
          <span slot="title">用户中心</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="user_list">用户列表</el-menu-item>
          <el-menu-item index="user_info">用户信息</el-menu-item>
          <el-menu-item index="user_auth">用户权限</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
</template>

<script>
  export default {
    name: "sidebar",
    data() {
      return {
      }
    },
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
    },
    created(){
      // open(index, 2);
    },
    components:{
    }
  }
</script>

<style scoped>

</style>