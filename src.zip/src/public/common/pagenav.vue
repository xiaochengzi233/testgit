<!--分页导航组件-->
<template>
  <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage"
      :page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
  export default {
    name: "pagenav",
    methods: {
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      }
    },
    props:{
      total:{
        type: Number,
        default: 0
      },
      currentPage:{
        type: Number,
        default: 1
      },
      pageSize:{
        type: Number,
        default: 8
      }
    },
    data() {
      return {
      };
    }
  }
</script>

<style scoped>

</style>