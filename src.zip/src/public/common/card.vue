<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span style="text-align: center">设备健康状况</span>
      <el-button class="el-icon-refresh-right" style="float: right; padding: 3px 0"></el-button>
    </div>
  </el-card>
</template>

<script>
  export default {
    name: "card"
  }
</script>

<style scoped>

</style>