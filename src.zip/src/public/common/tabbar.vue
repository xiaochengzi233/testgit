<!--选项卡-->
<template>
  <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick" :stretch="true" style="border: 0px;margin-top: 5px;height: 85vh">
    <el-tab-pane v-for="(value, name) in tabname" :label="value" :name="name">
      <slot></slot>
      <pagenav :total="total" style="text-align: center; position: fixed; bottom: 10px"></pagenav>
    </el-tab-pane>
  </el-tabs>
</template>

<script>
  import pagenav from '../common/pagenav'
  import {request} from "../../network/request";

  export default {
    name: "tabbar",
    props:{
      tabname:{
        type:Object,
        default: {}
      },
      active: String,
      total: 0,
    },
    data(){
      return {
        activeName: '',
      }
    },
    methods: {
      handleClick(tab, event) {
        this.$emit('device_request',this.activeName);
      }
    },
    created(){
      this.activeName = this.active;
      console.log(this.tabname);
    },
    components:{
      pagenav
    }
  }
</script>

<style scoped>

</style>