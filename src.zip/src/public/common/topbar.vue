<!--homepage-topbar-->
<template>
  <el-row class="topbar">
    <!--logo-->
    <el-col :span="3">
      <el-image fit="fill" :src="logo"></el-image>
    </el-col>
    <!--label-->
    <el-col :span="4">
      <h4>工业设备云检测平台</h4>
    </el-col>
    <!--user_tips-->
    <el-col :span="9" :offset="8">
      <h4 style="float: right; cursor: pointer" @click="exit()">
        <el-divider direction="vertical"></el-divider>
        退出
        <i class="el-icon-switch-button"></i>
      </h4>
      <h4 style="float:right">修改密码</h4>
      <h4 prefix-icon="el-icon-user" style="float:right">
        <i class="el-icon-user"></i>
        您好！{{ username }}
        <el-divider direction="vertical"></el-divider>
      </h4>
    </el-col>
  </el-row>
</template>

<script>
  import logo from "assets/img/logo-lzkj-x.png"
  export default {
    name: "topbar",
    props:{
      username: '',
    },
    data(){
      return {
        logo: logo,
      }
    },
    methods:{
      exit(){
        this.$router.push('/homepage');
      }
    }
  }
</script>

<style scoped>
  .topbar{
    min-height: 5vh;
    background-color: #181f29;
  }

  h4 {
    margin: 0;
    padding: 0;
    height: 5vh;
    line-height: 5vh;
    color: white;
  }
</style>