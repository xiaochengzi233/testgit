<template>
  <div>
    设备状态
  </div>
</template>

<script>
  export default {
    name: "device_status",
    created(){
      console.log('设备状态我创建了');
    }
  }
</script>

<style scoped>

</style>