<template>
  <!-- 1 -->
  <!-- <tabbar
  :tabname="tabbar"
  :total="total"
  :activeName="activeName"
  @device_request="device_request">

    <el-row class="health-left-content-s" v-for="(item,index) in device_list" :key="index">
      <el-col :span="4">

        <img style="width:50px;height:50px" :src="base_url+item.image" alt="无法显示图片">
      </el-col>
      <el-col class="health-left-content-s-text" :span="10">
        <h5 style="font-weight: bold">{{ item.device_name }}:{{ item.device_id }}</h5>
        <h5 style="font-weight: lighter"><small>{{ item.location }}</small></h5>
        <h5>健康指标：{{ item.device_health }}</h5>
      </el-col>
      <el-col :span="5">
        <h4>严重异常</h4>
        <h5>{{ item.diag_datetime }}</h5>
      </el-col>
      <el-col :span="5">
        <h3 class="health-left-content-s-search" @click="more_detail(item.device_id)">查看</h3>
      </el-col>
    </el-row>
  </tabbar> -->



  <!-- 2 -->
  <div class="health-left-content">
    <tabbar
      :tabname="tabbar"
      :active="activeName"
      :total="total"
      @device_request="device_request"
      v-model="isdata"
    >
      <!-- 在tabbar组件中加入内容 -->
      <!-- 有数据 -->
      <div v-if="isdata==true">
        <el-row class="health-left-content-s" v-for="(item,index) in device_list" :key="index">
          <el-col :span="4" class="health-left-content-one">
            <!-- 图片需要自适应要修改 -->
            <div class="aa">
              <img style="width:50px;height:50px" :src="base_url+item.image" alt="无法显示图片" />
            </div>
          </el-col>
          <el-col class="health-left-content-two" :span="10">
            <div class="aa">
              <h5 style="font-weight: bold">{{ item.device_name }}:{{ item.device_id }}</h5>
              <h5 style="font-weight: lighter">
                <small>{{ item.location }}</small>
              </h5>
              <h5>健康指标：{{ item.device_health }}</h5>
            </div>
          </el-col>
          <el-col :span="5" class="health-left-content-three">
            <div class="aa">
              <h4>严重异常</h4>
              <h5>{{ item.diag_datetime }}</h5>
            </div>
          </el-col>
          <el-col :span="5" class="health-left-content-four">
            <div class="aa">
              <h3 class="health-left-content-s-search" @click="more_detail(item.device_id + '  ' + item.device_name)">查看</h3>
            </div>
          </el-col>
        </el-row>
      </div>
      <!-- 无数据 -->
      <div v-else>
        <p style="font-size:60px">暂无数据</p>
      </div>

    </tabbar>
  </div>
</template>

<script>
  import {request} from "../../../../network/request";
  import tabbar from 'public/common/tabbar'
  export default {
    name: "device_list",
    data(){
      return{
        tabbar:{
          'all': '全部',
          'normal': '正常',
          'planned_stop': '计划停机',
          'warning': '告警',
          'hang_up': '意外停机',
          'sensor_offline': '传感器离线',
        },
        activeName: 'all',
        total: 0,
        page: 1,
        device_list: '',
        base_url: 'http://117.78.37.249:8001/',
        // 用来判断连接上api之后有数据传入
        isdata: true
      }
    },
    methods:{
      devicelist_get(){
        let formdata_device = new FormData();
        formdata_device.append('enterprise_id', '');
        formdata_device.append('device_status', this.activeName);
        formdata_device.append('search_field', '');
        formdata_device.append('paging', this.page);
        request({
          url: 'device/index/',
          method: 'post',
          data: formdata_device
        }).then(res => {
          console.log(res);
          this.device_list = res.data.device_list;
          this.total = res.data.n_device;
          console.log(this.total);
          if(this.total==0){
            this.isdata=false;
          }else{
            this.isdata=true;
          }
        }).catch(err => {
          console.log(err);
        })
      },
      device_request(request_object){
        this.activeName = request_object.activeName;
        this.page = request_object.paging;
        this.devicelist_get();
      },
      more_detail(selected){
        this.$router.replace('detail', selected);
      }
    },
    mounted(){
      this.devicelist_get(this.page);
    },
    components:{
      tabbar
    }
  }
</script>

<style>
  /* 最外层放置tabbar的盒子样式 */
  .health-left-content{
    border: 1px solid #324156;
    border-radius: 1%;
    background-color: #1b232f;
    color: white;
  }
  /* 每条数据的总格式 */
  .health-left-content-s {
    height: 80px;
    background-color: #181f29;
    margin-top: 1%;
  }
  /* 每条数据中每格的总格式 */
  .health-left-content-s > .el-col {
    height: 100%;
  }
  /* 设置每格数据的水平垂直对齐方式 */
  .health-left-content-one,
  .health-left-content-two,
  .health-left-content-three,
  .health-left-content-four {
    text-align: left;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  /* 每行第四格"查看"样式设置 */
  .health-left-content-s-search {
    cursor: pointer;
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin: 0;
    margin-top: 6px;
    font-weight: lighter;
  }
</style>