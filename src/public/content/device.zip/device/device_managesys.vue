<template>
  <el-row :gutter="4" class="device-el-row">
    <!--左侧设备健康状况-->
    <!-- <el-col :span="12">
      <el-card :body-style="{padding:0}">
        <div>
          <h3 style="text-align: center;color: white">
            设备健康状况
            <i class="el-icon-refresh-right" style="float: right;padding-top:4px;cursor: pointer" @click="device_refresh"></i>
          </h3>
          <tabbar :tabname="tabbar" :active="activeName" :total="total" @device_request="device_request">
            <el-row v-for="item in device_list" style="margin-bottom: 8px; background-color: #181f29; height: 80px">
              <el-col :span="12">
                <el-row>
                  <el-col :span="6">
                    <el-image :src="base_url+item.image" fit="contain"></el-image>
                  </el-col>
                  <el-col :span="16" :offset="2">
                    <h5 style="font-weight: bold">{{ item.device_name }} &emsp;&emsp; {{ item.device_id }} </h5>
                    <h5 style="font-weight: lighter"><small>{{ item.location }}</small></h5>
                    <h5>健康指标：{{ item.device_health }}</h5>
                  </el-col>
                </el-row>
              </el-col>
              <el-col :span="12">
                <el-row>
                  <el-col :span="16">
                    <h4 style="margin-top: 15px;text-align: center">严重异常</h4>
                    <h5 style="text-align: center">{{ item.diag_datetime }}</h5>
                  </el-col>
                  <el-col :span="8">
                    <h3 style="cursor: pointer;line-height: 80px;margin-top: 0;text-align: center" @click="more_detail(item.device_id)">查看</h3>
                  </el-col>
                </el-row>
              </el-col>
            </el-row>
          </tabbar>
        </div>
      </el-card>
    </el-col>-->

    <!-- 修改左侧页面 -->
    <el-col :span="12" class="health-left">
      <div class="health-left-all">
        <h3>
          设备健康状况
          <i class="el-icon-refresh-right" @click="device_refresh"></i>
        </h3>
        <!-- 左侧页面下方的内容引入tabbar组件 -->
        <div class="health-left-content">
          <tabbar
            :tabname="tabbar"
            :active="activeName"
            :total="total"
            @device_request="device_request"
          >
            <!-- 在tabbar组件中加入内容 -->
            <el-row class="health-left-content-s" v-for="(item,index) in device_list" :key="index">
              <el-col :span="4" class="health-left-content-one">
                <!-- 图片需要自适应要修改 -->
                <div class="aa">
                  <img style="width:50px;height:50px" :src="base_url+item.image" alt="无法显示图片" />
                </div>
              </el-col >
              <el-col class="health-left-content-two" :span="10">
                <div class="aa">
                  <h5 style="font-weight: bold">{{ item.device_name }}:{{ item.device_id }}</h5>
                  <h5 style="font-weight: lighter">
                    <small>{{ item.location }}</small>
                  </h5>
                  <h5>健康指标：{{ item.device_health }}</h5>
                </div>
              </el-col>
              <el-col :span="5" class="health-left-content-three">
                <div class="aa">
                  <h4>严重异常</h4>
                  <h5>{{ item.diag_datetime }}</h5>
                </div>
              </el-col>
              <el-col :span="5"  class="health-left-content-four">
                <div class="aa">
                  <h3 class="health-left-content-s-search" @click="more_detail(item.device_id)">查看</h3>
                </div>
              </el-col>
            </el-row>
          </tabbar>
        </div>
      </div>
    </el-col>

    <!--右侧 设备健康指数、报警信息和传感器、设备总览、设备温度统计、设备总体效率-->
    <el-col :span="12">
      <el-row :gutter="4">
        <!--设备健康指数-->
        <el-col :span="8" style="height: 230px">
          <el-card :body-style="{padding:0}" class="health-point">
            <h3 style="color: white">
              <small>设备健康指数</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider style="margin-top: 4px"></el-divider>
            <div id="chart1" style="height: 185px; width:100%"></div>
          </el-card>
        </el-col>
        <!--报警信息、传感器-->
        <el-col :span="16" style="height: 230px">
          <!-- 报警信息-报警数量 -->
          <el-card :body-style="{padding:0}" class="error-message">
            <h3 style="color: white">
              <small>报警信息</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider></el-divider>
            <el-row>
              <el-col :span="4" style="display:flex; justify-content:center">
                <el-image :src="bluefire" class="error-image" fit="'fit'"></el-image>
              </el-col>
              <el-col :span="8">
                <div style="border-right: 0.5px solid white">
                  <h3
                    style="font-weight: bold; text-align: center; margin-top: 10px"
                  >{{ warning.warning_num }}</h3>
                  <h4 style="font-weight: bold; text-align: center">报警总数</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <div style="border-right: 0.5px solid white">
                  <h3
                    style="font-weight: bold; text-align: center; margin-top: 10px"
                  >{{ warning.handled}}</h3>
                  <h4 style="font-weight: bold; text-align: center">已处理</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <div style="border-right: 0.5px solid white">
                  <h3
                    style="font-weight: bold; text-align: center; margin-top: 10px"
                  >{{ warning.not_handled }}</h3>
                  <h4 style="font-weight: bold; text-align: center">未处理</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <h3
                  style="font-weight: bold; text-align: center; margin-top: 10px"
                >{{ warning.urgency }}</h3>
                <h4 style="font-weight: bold; text-align: center">紧急</h4>
              </el-col>
            </el-row>
          </el-card>
          <!-- 报警信息-传感器 -->
          <el-card :body-style="{padding:0}" class="error-message">
            <h3 style="color: white">
              <small>报警信息</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider></el-divider>
            <el-row>
              <el-col :span="4">
                <el-image :src="purplefire" class="error-image"></el-image>
              </el-col>
              <el-col :span="8">
                <div style="border-right: 0.5px solid white">
                  <h3 style="font-weight: bold; text-align: center; margin-top: 10px">{{ sensor }}</h3>
                  <h4 style="font-weight: bold; text-align: center">传感器</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <div style="border-right: 0.5px solid white">
                  <h3 style="font-weight: bold; text-align: center; margin-top: 10px">{{ sensor }}</h3>
                  <h4 style="font-weight: bold; text-align: center">在线</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <div style="border-right: 0.5px solid white">
                  <h3 style="font-weight: bold; text-align: center; margin-top: 10px">{{ sensor }}</h3>
                  <h4 style="font-weight: bold; text-align: center">离线</h4>
                </div>
              </el-col>
              <el-col :span="4">
                <h3 style="font-weight: bold; text-align: center; margin-top: 10px">{{ sensor }}</h3>
                <h4 style="font-weight: bold; text-align: center">异常</h4>
              </el-col>
            </el-row>
          </el-card>
        </el-col>

        <el-col :span="12" style="margin-top: 4px">
          <el-card :body-style="{padding:0}">
            <h3 style="color: white">
              <small>设备总览(设备总数{{ total }})</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider style="margin-top: 4px"></el-divider>
            <el-col :span="12">
              <div id="chart2" style="height: 180px"></div>
            </el-col>
            <el-col :span="12">
              <h4 style="margin-top: 30%;margin-left: 20%">
                <el-image :src="greensquare" fit="fill" style="margin-right: 5%"></el-image>
                正常：&emsp;{{ device.normal }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="orangesquare" fit="fill" style="margin-right: 5%"></el-image>
                预警：&emsp;{{ device.warning }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="redsquare" fit="fill" style="margin-right: 5%"></el-image>
                危险：&emsp;{{ device.danger }}
              </h4>
            </el-col>
          </el-card>
        </el-col>
        <el-col :span="12" style="margin-top: 4px">
          <el-card :body-style="{padding:0}">
            <h3 style="color: white">
              <small>设备温度统计</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider style="margin-top: 4px"></el-divider>
            <el-col :span="12">
              <div id="chart3" style="height: 180px"></div>
            </el-col>
            <el-col :span="12">
              <h4 style="margin-top: 30%;margin-left: 20%">
                <el-image :src="greensquare" fit="fill" style="margin-right: 5%"></el-image>
                正常：&emsp;{{ tempreture.mild }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="bluesquare" fit="fill" style="margin-right: 5%"></el-image>
                低温：&emsp;{{ tempreture.cold }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="redsquare" style="margin-right: 5%"></el-image>
                高温：&emsp;{{ tempreture.hot }}
              </h4>
            </el-col>
          </el-card>
        </el-col>
        <el-col :span="12" style="margin-top: 4px">
          <el-card :body-style="{padding:0}">
            <h3 style="color: white">
              <small>设备总体效率</small>
              <i
                class="el-icon-refresh-right"
                style="float: right;padding-top:4px;cursor: pointer"
                @click="device_refresh"
              ></i>
            </h3>
            <el-divider style="margin-top: 4px"></el-divider>
            <el-col :span="12">
              <div id="chart4" style="height: 180px"></div>
            </el-col>
            <el-col :span="12">
              <h4 style="margin-top: 30%;margin-left: 20%">
                <el-image :src="greensquare" fit="fill" style="margin-right: 5%"></el-image>
                额定：{{ tempreture.mild }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="orangesquare" fit="fill" style="margin-right: 5%"></el-image>
                低负载：{{ tempreture.cold }}
              </h4>
              <h4 style="margin-top: 5%; margin-left: 20%">
                <el-image :src="redsquare" fit="fill" style="margin-right: 5%"></el-image>
                高负载：{{ tempreture.hot }}
              </h4>
            </el-col>
          </el-card>
        </el-col>
      </el-row>
    </el-col>
  </el-row>
</template>
<script>
import tabbar from "public/common/tabbar";
import { request } from "network/request";

import purplefire from "assets/img/purplefire.png";
import bluefire from "assets/img/bluefire.png";
import redsquare from "assets/img/redsquare.png";
import orangesquare from "assets/img/orangesquare.png";
import greensquare from "assets/img/greensquare.png";
import bluesquare from "assets/img/bluesquare.png";

export default {
  name: "device_managesys",
  data() {
    return {
      purplefire: purplefire,
      bluefire: bluefire,
      bluesquare: bluesquare,
      greensquare: greensquare,
      orangesquare: orangesquare,
      redsquare: redsquare,
      tabbar: {
        all: "全部",
        normal: "正常",
        planned_stop: "计划停机",
        warning: "告警",
        hang_up: "意外停机",
        sensor_offline: "传感器离线"
      },
      activeName: "all",
      device_list: [],
      total: 0,
      base_url: "http://117.78.37.249:8001/",
      warning: "",
      sensor: 0,
      device: "",
      tempreture: "",
      power: ""
    };
  },
  // mounted(){
  //   window.onresize=function(){
  //     location.reload();
  //   }
  // },
  methods: {
    device_request(status) {
      let formdata_device = new FormData();
      formdata_device.append("enterprise_id", "");
      formdata_device.append("device_status", status.activeName);
      formdata_device.append("search_field", "");
      formdata_device.append("paging", status.paging);
      request({
        url: "device/index/",

        method: "post",
        data: formdata_device
      })
        .then(res => {
          console.log(res);
          this.device_list = res.data.device_list;
          this.total = res.data.n_device;
          console.log(this.total);
        })
        .catch(err => {
          console.log(err);
        });
    },
    device_refresh() {
      console.log("我要刷新");
    },
    getchart(data) {
      console.log(data);
      var myChart1 = echarts.init(document.getElementById("chart1"));
      var option1 = {
        series: {
          type: "pie",
          clockWise: false,
          radius: [50, 70],
          label: false,
          itemStyle: {
            normal: {
              color: function(params) {
                if (data[2].health_status >= 75) return "green";
                else if (data[2].health_status >= 60) return "orange";
                else return "red";
              }
              // shadowColor: 'blue',
            }
          },
          hoverAnimation: false,
          data: [
            {
              value: data[2].health_index,
              label: {
                normal: {
                  formatter: function(params) {
                    return params.value + "%" + "\n" + data[2].health_status;
                  },
                  position: "center",
                  show: true,
                  textStyle: {
                    fontSize: "20",
                    fontWeight: "bold",
                    color: function(params) {
                      if (data[2].health_status >= 75) return "green";
                      else if (data[2].health_status >= 60) return "orange";
                      else return "red";
                    }
                  }
                }
              }
            },
            {
              value: 100 - data[2].health_index,
              itemStyle: { color: "#dfeaff" }
            }
          ]
        }
      };
      myChart1.setOption(option1);

      var myChart2 = echarts.init(document.getElementById("chart2"));
      var option2 = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            name: "设备总览",
            type: "pie",
            radius: ["50%", "70%"],
            label: false,
            data: [
              {
                value: data[0].normal,
                name: "正常",
                itemStyle: { color: "green" }
              },
              {
                value: data[0].warning,
                name: "预警",
                itemStyle: { color: "orange" }
              },
              {
                value: data[0].danger,
                name: "危险",
                itemStyle: { color: "red" }
              }
            ]
          }
        ]
      };
      myChart2.setOption(option2);

      var myChart3 = echarts.init(document.getElementById("chart3"));
      var option3 = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            name: "设备温度统计",
            type: "pie",
            radius: ["50%", "70%"],
            label: false,
            data: [
              {
                value: data[1].mild,
                name: "正常",
                itemStyle: { color: "green" }
              },
              {
                value: data[1].cold,
                name: "低温",
                itemStyle: { color: "blue" }
              },
              { value: data[1].hot, name: "高温", itemStyle: { color: "red" } }
            ]
          }
        ]
      };
      myChart3.setOption(option3);

      var myChart4 = echarts.init(document.getElementById("chart4"));
      var option4 = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            name: "设备功率统计",
            type: "pie",
            radius: ["50%", "70%"],
            label: false,
            data: [
              { value: 335, name: "额定功效", itemStyle: { color: "green" } },
              { value: 234, name: "低负载", itemStyle: { color: "orange" } },
              { value: 135, name: "高温高负载", itemStyle: { color: "red" } }
            ]
          }
        ]
      };
      myChart4.setOption(option4);
    },

    more_detail(id) {
      this.$router.replace("/device_detail", id);
    }
  },
  created() {
    let formdata_device = new FormData();
    formdata_device.append("enterprise_id", "");
    formdata_device.append("device_status", this.activeName);
    formdata_device.append("search_field", "");
    formdata_device.append("paging", "1");
    request({
      url: "device/index/",
      method: "post",
      data: formdata_device
    })
      .then(res => {
        console.log(res);
        this.device_list = res.data.device_list;
        this.total = res.data.n_device;
      })
      .catch(err => {
        console.log(err);
      });
    request({
      url: "device/index/",
      method: "get"
    })
      .then(res => {
        this.device = res.data[0];
        this.tempreture = res.data[1];
        this.warning = res.data[3];
        // this.sensor = res.data[4];
        // this.power = res.datat[5];
        this.getchart(res.data);
      })
      .catch(err => {
        console.log(err);
      });
  },
  components: {
    tabbar
  }
};
</script>

<style scoped>
.text-center {
  text-align: center;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}
/*.el-card__header {*/
/*padding: 0;*/
/*}*/
.el-divider {
  margin: 5px 0;
}
h1,
h2,
h3,
h4,
h5,
h6 {
  margin: 0;
  margin-top: 6px;
  font-weight: lighter;
}
.health-point {
  box-sizing: border-box;
}
.error-message {
  height: 113px;
  margin-bottom: 4px;
  box-sizing: border-box;
}
.error-image {
  height: 100%;
  padding: 8px;
  padding-top: 0px;
}
/* 修改左侧页面 */
.health-left {
  /* 先固定高度之后再改 */
  /* height: 800px; */
  border: 1px solid #324156;
  border-radius: 1%;
  background-color: #1b232f;
}
.health-left-all {
  text-align: center;
  color: white;
  /* background-color: #128; */
}
/* 左侧顶栏刷新按钮 */
.health-left-all i {
  float: right !important;
  cursor: pointer;
  line-height: 25px;
}
.health-left-content-s {
  height: 80px;
  background-color: #181f29;
  margin-top: 1%;
}
/*  */
.health-left-content-s > .el-col {
  height: 100%;
  /* border: 1px solid #000; */
}
.health-left-content {
  /* height: 100vh; */
  background-color: #fff;
  /* position: relative; */
}
/* content中第二格部分 */
.health-left-content-one, .health-left-content-two,.health-left-content-three,.health-left-content-four{
  text-align: left;
  display: flex;
  justify-content: center;
  align-items: center;
}
/* content中第四格部分 */
.health-left-content-s-search {
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
}
.device-el-row {
  height: 100%;
}
.aa {
}
</style>