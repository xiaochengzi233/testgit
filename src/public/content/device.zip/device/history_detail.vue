<template>
  <router-view></router-view>
</template>

<script>
  export default {
    name: "history_detail",
  }
</script>

<style scoped>

</style>