<template>
<div id="main">
  <div class="block">
    <el-date-picker
      type="datetimerange"
      v-model="time"
      start-placeholder="开始时间"
      end-placeholder="结束时间"
      :default-time="['12:00:00']"
      size="small"
      @change="time_change">
    </el-date-picker>
  </div>
  <div id="feature">  
  </div>
  </div>
</template>

<script>
  export default {
    name: "feature",
    props: ['feature_data'],
    data(){
      return{
        time: '',
        start_time: '',
        end_time: ''
      }
    },
    methods:{
      time_change(){
        this.$emit('time_change', this.start_time, this.end_time);
      }
    },
    watch:{
      time: function (new_time) {
        this.start_time = new_time[0];
        this.end_time = new_timee[1];
      }
    },
    mounted(){
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById('feature'));

      // 指定图表的配置项和数
      var option = {
        radar: {
          name: {
            textStyle: {
              color: '#fff',
              borderRadius: 3,
              padding: [3, 5]
            }
          },
          indicator: [{
            name: '特征1',
            max: 6500
          },
            {
              name: '特征2',
              max: 16000
            },
            {
              name: '特征3',
              max: 30000
            },
            {
              name: '特征4',
              max: 38000
            },
            {
              name: '特征5',
              max: 52000
            },
          ]
        },
        series: [{
          name: '特征（stigma））',
          type: 'radar',
          areaStyle: {
            normal: {}
          },
          data: [{
            value: [4300, 10000, 28000, 35000, 50000, 19000],
            name: '特征（stigma）'
          }]
        }]
      };

      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(option);
    }
  }
</script>

<style scoped>
  #feature{
    min-height: calc(85vh - 117px);
  }
  #main .block{
    height: 48px;
  }
  .el-date-editor--datetimerange.el-input__inner{
    border:none;
  }
</style>