<template>
  <div id="main">
    <div class="block">
      <el-date-picker
      type="datetimerange"
      v-model="time"
      start-placeholder="开始时间"
      end-placeholder="结束时间"
      :default-time="['12:00:00']"
      size="small">
      </el-date-picker>
    </div>
    <div id="diagnosis"></div>
  </div>
</template>

<script>
	export default {
		name: "diagnosis",
    props: ['diagnosis_data'],
		data() {
			return {
        time: '',
        start_time: '',
        end_time: ''
      }
    },
    methods:{
      time_change(){
        this.$emit('time_change', this.start_time, this.end_time);
      }
    },
    watch:{
      time: function (new_time) {
        this.start_time = new_time[0];
        this.end_time = new_timee[1];
      }
    },
		mounted() {
			var myChart = echarts.init(document.getElementById('diagnosis'));

			var option = {
				xAxis: {
					data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,30],
					axisLine: {
            lineStyle: {
              // 设置x轴颜色
              color: '#fff'
            }
        }
				},
				yAxis: {
					data: ['正常', '危险', '警告'],
					axisLine: {
          lineStyle: {
            // 设置y轴颜色
            color: '#fff'
          }
        }
				},
				series: [{
					symbolSize: 18,
					//要改
					data: [
						[1, '正常'],
						[2, '正常'],
						[3, '警告'],
						[4, '正常'],
						[5, '正常'],
						[6, '危险'],
						[7, '警告'],
						[8, '正常'],
						[9, '警告'],
						[10, '正常'],
						[11, '危险'],
						[12, '正常'],
						[13, '危险'],
						[14, '危险'],
						[15, '正常'],
						[16, '正常'],
						[17, '正常'],
						[18, '警告'],
						[19, '正常'],
						[20, '正常'],
						[21, '警告'],
						[22, '正常'],
						[23, '危险'],
						[24, '正常'],
						[25, '正常'],
						[26, '警告'],
						[27, '正常'],
						[28, '危险'],
						[29, '正常'],
						[30, '正常'],
					],
					type: 'scatter'
				}],
				backgroundColor: '#1B232F',
				color: '#a4e2c6',
			};

			myChart.setOption(option);
		}
	}
</script>

<style scoped>
  #diagnosis{
    min-height: calc(85vh - 117px);
  }
  #main .block{
    height: 48px;
  }
  .el-date-editor--datetimerange.el-input__inner{
    border:none;
  }
</style>
