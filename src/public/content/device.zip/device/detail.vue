<template>
  <div>
    <el-row style="background-color: #1B232F;min-height: 5vh">
      <!--已选择设备的信息 设备id detail location-->
      <h4 style="float: left;margin-right: 20px; margin-top: 5px">已选择设备：空</h4>
      <el-select v-model="sensor_id" placeholder="请选择传感器" size="small">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
          @change="sensor_change">
          <!--可禁用、可清空、可搜索-->
        </el-option>
      </el-select>
      <el-button
        type="text"
        style="float: right;"
        @click="get_device_list">
        选择设备
        <i class="el-icon-back"></i>
      </el-button>
    </el-row>
    <el-row :gutter="4">
      <el-col :span="filelist_width">
        <file_list :date_change="date_change" :datetype_change="datatype_change" :data_switch="data_switch"></file_list>
      </el-col>
      <el-col :span="visual_width">
        <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick" :stretch="true" style="border: 0px;margin-top: 5px;">
          <el-tab-pane label="频谱" name="spectrum">
            <spectrum v-if="activeName === 'spectrum'" :spectrum_data="data_list"></spectrum>
          </el-tab-pane>
          <el-tab-pane label="波形" name="wav">
            <wav v-if="activeName === 'wav'" :wav_data="data_list"></wav>
          </el-tab-pane>
          <el-tab-pane label="特征" name="feature">
            <feature v-if="activeName === 'feature'" :feature_data="data_list" :time_change="time_change"></feature>
          </el-tab-pane>
          <el-tab-pane label="诊断" name="diagnosis">
            <diagnosis v-if="activeName === 'diagnosis'" :diagnosis_data="data_list" :time_change="time_change"></diagnosis>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>
  </div>

</template>

<script>
  import {request} from "network/request";
  import file_list from './device_file/file_list';
  import wav from './device_visual/wav'
  import spectrum from './device_visual/spectrum'
  import feature from './device_visual/feature'
  import diagnosis from './device_visual/diagnosis'
  export default {
    name: "detail",
    data(){
      return {
        filelist_width: 6,
        visual_width: 18,
        options: [{
          value: '1',
          label: '1号传感器'
        }, {
          value: '2',
          label: '2号传感器'
        }],
        //保存请求到的数据
        data_list: '',
        //选项卡状态
        activeName: 'spectrum',
        sensor_id: ''
      }
    },
    methods:{
      //选项卡为频谱、波形的时候 请求文件列表
      get_filelist(){
        let formdata_device = new FormData();
        formdata_device.append('sensor_id', this.sensor_id);
        formdata_device.append('data_type', this.activeName);
        request({
          url: '',
          method: 'post',
          data: formdata_device
        }).then(res => {
          console.log(res);
          this.device_list = res.data.device_list;
          // this.total = res.data.n_device;
        }).catch(err => {
          console.log(err);
        })
      },
      //请求波形、频谱与诊断、特征数据
      get_datalist(){
        let formdata_device = new FormData();
        formdata_device.append('sensor_id', this.sensor_id);
        formdata_device.append('data_type', this.activeName);
        request({
          url: '',
          method: 'post',
          data: formdata_device
        }).then(res => {
          console.log(res);
          this.device_list = res.data.device_list;
          // this.total = res.data.n_device;
        }).catch(err => {
          console.log(err);
        })
      },
      //返回选择设备
      get_device_list(){
        this.$router.replace('device_list');
      },
      //选项卡切换 调用接口
      handleClick(){
        if(this.activeName == 'feature' || this.activeName == 'diagnosis')
        {
          this.filelist_width = 0;
          this.visual_width = 24;
        }
        else{
          this.filelist_width = 6;
          this.visual_width = 18;
        }
      },
      //sensor_id 改变重新请求数据
      sensor_change(){
        get_filelist();
      },
      //文件列表下的日期发送请求
      date_change(){

      },
      //文件列表下的高频低频切换
      datatype_change(){

      },
      //文件列表下的查看文件
      data_switch(){

      },
      //诊断跟特征下的时间选择变化
      time_change(){

      }
    },
    mounted(){
      this.$alert('请选择设备后查看', '提示', {
        confirmButtonText: '确定',
      });
    },
    components:{
      file_list,
      wav,
      spectrum,
      feature,
      diagnosis
    }
  }
</script>

<style scoped>
  h4 {
    padding: 0;
    margin: 0;
    color: white;
    font-weight: lighter;
  }
</style>