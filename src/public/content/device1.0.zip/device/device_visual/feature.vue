<template>
  <div id="feature"></div>
</template>

<script>
  export default {
    name: "feature",
    data(){
      return{
        feature_data: ''
      }
    },
    mounted(){
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById('feature'));

      // 指定图表的配置项和数
      var option = {
        radar: {
          name: {
            textStyle: {
              color: '#fff',
              borderRadius: 3,
              padding: [3, 5]
            }
          },
          indicator: [{
            name: '特征1',
            max: 6500
          },
            {
              name: '特征2',
              max: 16000
            },
            {
              name: '特征3',
              max: 30000
            },
            {
              name: '特征4',
              max: 38000
            },
            {
              name: '特征5',
              max: 52000
            },
          ]
        },
        series: [{
          name: '特征（stigma））',
          type: 'radar',
          areaStyle: {
            normal: {}
          },
          data: [{
            value: [4300, 10000, 28000, 35000, 50000, 19000],
            name: '特征（stigma）'
          }]
        }]
      };

      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(option);
    }
  }
</script>

<style scoped>
  #feature{
    width: 100%;
    height: 600px;
  }
</style>