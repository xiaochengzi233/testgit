<template>
	<div id="main"></div>
</template>

<script>
	export default {
		name: "diagnoise",
		data() {
			return {
				diagnoise_data: ''
			}
		},
		mounted() {
			var myChart = echarts.init(document.getElementById('main'), 'dark');

			var option = {
				xAxis: {
					data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,30
					]
				},
				yAxis: {
					data: ['正常', '危险', '警告']
				},
				series: [{
					symbolSize: 18,
					//要改
					data: [
						[1, '正常'],
						[2, '正常'],
						[3, '警告'],
						[4, '正常'],
						[5, '正常'],
						[6, '危险'],
						[7, '警告'],
						[8, '正常'],
						[9, '警告'],
						[10, '正常'],
						[11, '危险'],
						[12, '正常'],
						[13, '危险'],
						[14, '危险'],
						[15, '正常'],
						[16, '正常'],
						[17, '正常'],
						[18, '警告'],
						[19, '正常'],
						[20, '正常'],
						[21, '警告'],
						[22, '正常'],
						[23, '危险'],
						[24, '正常'],
						[25, '正常'],
						[26, '警告'],
						[27, '正常'],
						[28, '危险'],
						[29, '正常'],
						[30, '正常'],
					],
					type: 'scatter'
				}],
				backgroundColor: '#1B232F',
				color: '#a4e2c6',
			};

			myChart.setOption(option);
		}
	}
</script>

<style scoped>
	#main{
	  width: 100%;
	  height: 600px;
	}
</style>
