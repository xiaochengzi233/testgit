<template>
  <div id="wav"></div>
</template>

<script>
  export default {
    name: "wav",
    props: {

    },
    data() {
      return {
        wav_data: '',
      }
    },
    methods:{
      init(){
        var myChart = echarts.init(document.getElementById('wav'));
        var option = {
          tooltip: {
            trigger: 'item'
          },
          xAxis: {
            type: 'category',
            data: ['3:30', '4:00', '4:30', '5:00', '5:30', '6:00', '6:30'],
            axisLine: {
              lineStyle: {
                // 设置x轴颜色
                color: 'white',
                backgroundColor: 'rgba(0,0,0,0.7)',
              }
            }
          },
          yAxis: {
            type: 'value',
            data: this.wav_data,
            axisLine: {
              lineStyle: {
                show: false,
                // 设置y轴颜色
                color: 'white'
              }
            },
          },
          series: [{
            data: ['0','1','2','1.5','1','1.5','0.5'],
            type: 'line',
            smooth: true,
            color: '#a4e2c6',
          }]
        };
        myChart.setOption(option);
      }
    },
    mounted(){
      this.init();
    },
  }
</script>

<style scoped>
  #wav {
    width: 100%;
    height: 600px;
  }
</style>

<body>

</body>