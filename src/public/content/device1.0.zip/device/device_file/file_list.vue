<template>
  <div style="background-color: #1B232F; min-height: 85vh; margin-top: 4px;">
    <h4>
      文件列表
      <i class="el-icon-refresh-right" style="float: right;padding-top:4px;cursor: pointer" @click="device_refresh"></i>
    </h4>
    <!--<el-divider></el-divider>-->
    <el-date-picker
      v-model="value1"
      type="daterange"
      range-separator="-"
      start-placeholder="起始日期"
      end-placeholder="结束日期"
      unlink-panels
      size="small"
      format="yyyy 年 MM 月 dd 日"
      value-format="yyyy-MM-dd"
      style="margin-top: 5px">
    </el-date-picker>
    <el-row style="margin-top: 10px" v-for="item in filelist">
      <h4 style="float: left"><i class="el-icon-document"></i>2019-12-20</h4>
      <h4 style="float: right; margin-right: 20px">下载</h4>
      <h4 style="float: right; margin-right: 40px">查看</h4>
    </el-row>
  </div>
</template>

<script>
  export default {
    name: "file_list",
    data(){
      return{
        value1: '',
        filelist: [1,2,3,4,5,6,7,8,9],
      }
    },
    methods:{
      device_refresh(){

      }
    },
    watch:{
      value1: function (old) {
        console.log(this.value1[0] + this.value1[1]);
      }
    }
  }
</script>

<style scoped>
  h4 {
    padding: 0;
    margin: 0;
    margin-left: 5px;
    color: white;
    font-weight: lighter;
  }
  .el-divider {
    margin: 0;
  }
</style>