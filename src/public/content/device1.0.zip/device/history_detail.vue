<template>
  <div>
    <el-row style="background-color: #1B232F;min-height: 5vh">
      <h4 style="float: left;margin-right: 20px; margin-top: 5px">已选择设备：地区 id</h4>
      <el-select v-model="sensor_id" placeholder="请选择传感器" size="small">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        <!--可禁用、可清空、可搜索-->
        </el-option>
      </el-select>
      <el-button
        type="text"
        style="float: right;"
        @click="back">
        重新选择设备
        <i class="el-icon-back"></i>
      </el-button>
    </el-row>
    <el-row :gutter="4">
      <el-col :span="filelist_width">
        <file_list></file_list>
      </el-col>
      <el-col :span="visual_width">
        <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick" :stretch="true" style="border: 0px;margin-top: 5px;">
          <el-tab-pane label="频谱" name="spectrum">
            <spectrum v-if="activeName === 'spectrum'"></spectrum>
          </el-tab-pane>
          <el-tab-pane label="波形" name="wav">
            <wav v-if="activeName === 'wav'"></wav>
          </el-tab-pane>
          <el-tab-pane label="特征" name="feature">
            <feature v-if="activeName === 'feature'"></feature>
          </el-tab-pane>
          <el-tab-pane label="诊断" name="diagnoise">
            <diagnoise v-if="activeName === 'diagnoise'"></diagnoise>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>
  </div>

</template>

<script>
  import {request} from "network/request";
  import file_list from './device_file/file_list';
  import wav from './device_visual/wav'
  import spectrum from './device_visual/spectrum'
  import feature from './device_visual/feature'
  import diagnoise from './device_visual/diagnoise'
  export default {
    name: "history_detail",
    data(){
      return {
        filelist_width: 6,
        visual_width: 18,
        options: [{
          value: '1',
          label: '1号传感器'
        }, {
          value: '2',
          label: '2号传感器'
        }],
        value: '',
        activeName: 'spectrum',
        sensor_id: ''
      }
    },
    methods:{
      back(){
        this.$router.replace('/device_managesys');
      },
      handleClick(){
        if(this.activeName == 'feature' || this.activeName == 'diagnoise')
        {
          this.filelist_width = 0;
          this.visual_width = 24;
        }
        else{
          this.filelist_width = 6;
          this.visual_width = 18;
        }
      },
      get_filelist(){
        let formdata_device = new FormData();
        formdata_device.append('sensor_id', this.sensor_id);
        formdata_device.append('data_type', this.activeName);
        request({
          url: 'device/index/',
          method: 'post',
          data: formdata_device
        }).then(res => {
          console.log(res);
          this.device_list = res.data.device_list;
          this.total = res.data.n_device;
          console.log(this.total);
        }).catch(err => {
          console.log(err);
        })
      }
    },
    created(){
      console.log('历史详情我创建了');
    },
    components:{
      file_list,
      wav,
      spectrum,
      feature,
      diagnoise
    }
  }
</script>

<style scoped>
  h4 {
    padding: 0;
    margin: 0;
    color: white;
    font-weight: lighter;
  }
</style>